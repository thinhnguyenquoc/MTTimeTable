class clsGeneticAlgorithm
{

};