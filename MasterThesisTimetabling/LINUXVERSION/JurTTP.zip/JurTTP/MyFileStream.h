#include<iostream>
#include<sstream>
#include<fstream>
#include<istream>
#include<string>
using namespace std;
#define MAXLECT 50
#define MAXPROJ 50
#define MAXSESSION 7
