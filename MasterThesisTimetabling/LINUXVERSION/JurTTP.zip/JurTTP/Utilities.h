#define MAXLECT 71
#define MAXJURY 101
#define MAXPERIOD 60
#define NUMSLOT 3
//Just used from 0 to 42, MAXPERIOD must be divisible by 3


